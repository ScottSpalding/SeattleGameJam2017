// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "SeattleGameJam2017GameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class SEATTLEGAMEJAM2017_API ASeattleGameJam2017GameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
	
	
	
};
